import React from 'react';
import Hero from './Hero';

const HeroSection: React.FC = () => {
  return <Hero />;
};

export default HeroSection;